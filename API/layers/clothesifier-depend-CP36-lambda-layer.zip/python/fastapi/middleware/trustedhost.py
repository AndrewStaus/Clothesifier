from starlette.middleware.trustedhost import (  # noqa
    TrustedHostMiddleware as TrustedHostMiddleware,
)
